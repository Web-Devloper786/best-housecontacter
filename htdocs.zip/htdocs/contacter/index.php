<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Local House Contractor</title>
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
  <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <style>
    html {
      scroll-behavior: smooth;
      overflow-x: hidden
    }

    #main-img-wrapper {
  position: relative;
  overflow: hidden;
  height: 100vh;
  width: 100%;
}

#main-img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  transition: transform 0.5s ease-in-out;
}

#main-img:hover {
  transform: scale(1.05);
}

/* Optional: Dark overlay for better text readability */
#main-img-wrapper::after {
  content: "";
  position: absolute;
  top: 0;
  left: 0;
  height: 100%;
  width: 100%;
  background: rgba(0, 0, 0, 0.4);
  z-index: 1;
}

/* Hero Text Styling */


/* Responsive text scaling */
@media (max-width: 768px) {
  #main-img-wrapper {
    height: 70vh;
  }


}

@media (max-width: 480px) {
  #main-img-wrapper {
    height: 60vh;
  }


}
@media (max-width: 480px){
.navbar a :active{
 color:white;
}
}
@media (min-width: 1280px) {
  .navbar a:hover {
    background-color: rgb(233, 130, 13);
    color: white;
    border-radius: 8px;
    box-shadow: 0 8px 20px rgba(243, 151, 47, 0.6);
    transform: scale(1.05);
    transition: all 0.4s linear;
  }
}


.navbar {
  position: fixed;
  top: 0;
  width: 100%;
 box-shadow: 10px 10px 10px black;
  z-index: 50; /* ensure it stays on top */
  background-color: #cc7c14;
}
.navbar a{
  color: rgb(3, 3, 3);
  border-radius: 5px;

}
#drop a{
  color: black;
}
h2:hover {
  color: #db9334;
  transform: scale(1.05);
  text-shadow: 1px 1px 4px rgba(0, 0, 0, 0.2);
  transition: all 0.3s ease-in-out;
  cursor: pointer;
}
#one:hover {
  transform: scale(1.05);
  transition: transform 0.3s ease-in-out;
}
#to:hover {
  transform: scale(1.05);
  transition: transform 0.3s ease-in-out;
}
#three:hover{
  transform:scale(1.05);
  transition: transform 0.3s ease-in-out;
}
#card1 {
  transition: all 0.3s ease-in-out;
  border-radius: 12px;
}

#card1:hover {
  background-color: rgb(241, 145, 55);
  transform: scale(1.05);
  box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
}
#card3:hover {
  background-color: rgb(241, 145, 55);
  transform: scale(1.05);
  box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
}
#card2:hover {
  background-color: rgb(66, 65, 64);
  transform: scale(1.05);
  box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
}




#card1:hover,
#card1:hover h3,#card2:hover,
#card2:hover h3,#card3:hover,
#card3:hover h3 {
  color: white;

}

.card{
  padding: 20px;
}
.card p{
  cursor: pointer;
  font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
  font-size: 18px;
  line-height: 23px;
}

  </style>
</head>
<body class="bg-gray-50 text-gray-800">
  <nav class="navbar navbar-expand-lg fixed-top">
    <div class="container-fluid">
      <!-- Logo -->
      <a class="navbar-brand d-flex align-items-center" href="#">
        <img src="images/BASir ansari.png" alt="Basir Ansari Logo" style="height: 60px; object-fit: contain;">
      </a>
      
      
      <!-- Hamburger toggle button -->
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNavbar" aria-controls="mainNavbar" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
  
      <!-- Navbar links -->
      <div class="collapse navbar-collapse" id="mainNavbar" style="color:black">
        <ul class="navbar-nav ms-auto" >
          <li class="nav-item">
            <a class="nav-link" href="#about">About</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#services">Services</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#portfolio">Portfolio</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#contact">Contact</a>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
              More
            </a>
            <ul id="drop" class="dropdown-menu dropdown-menu-end">
              <li><a class="dropdown-item" href="#why">Why Us</a></li>
              <li><a class="dropdown-item" href="#testimonials">Testimonials</a></li>
            </ul>
          </li>
        </ul>
      </div>
    </div>
  </nav>
  <!-- Hero Section -->
  <div id="main-img-wrapper" data-aos="fade-in">
    <img id="main-img" class="img-fluid" src="images/zac-gudakov-5QLCohwVndQ-unsplash.jpg" alt="Hero Image" />
    <div id="hero-text" class="absolute inset-0 flex flex-col justify-center items-center text-center text-white p-4 z-20">
      <h1 class="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold drop-shadow-md">
        Build Your Dream Home With <span style="color:#db9334;">Basir Ansari </span>Contractors
      </h1>
      <p class="mt-2 text-sm sm:text-base md:text-lg drop-shadow">
        Expert Contractors. Honest Pricing. Quality Work.
      </p>
    </div>
    
  </div>
  
  <!-- About Section -->
  <section class="py-20 px-6" id="about">
    <div class="max-w-4xl mx-auto text-center" data-aos="fade-up">
      <h2 class="text-3xl font-bold mb-4">About Us</h2>
      <p class="text-lg">We are a local team of experienced contractors specializing in residential projects. From renovations to new builds, we provide quality work with honest pricing and dedicated customer service.</p>
    </div>
  </section>

  <!-- Services Section -->
  <section class="bg-white py-20 px-6" id="services">
    <div class="max-w-6xl mx-auto" data-aos="fade-right">
      <h2 class="text-3xl font-bold text-center mb-12">Our Services</h2>
      <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div id="card1" class="bg-gray-100 p-6 rounded shadow hover:shadow-lg transition duration-300" data-aos="zoom-in">
          <h3 class="text-xl font-bold mb-2">Home Renovation</h3>
          <p>Transform your space with our renovation expertise.</p>
        </div>
        <div id="card2" class="bg-gray-100 p-6 rounded shadow hover:shadow-lg transition duration-300" data-aos="zoom-in" data-aos-delay="100">
          <h3 class="text-xl font-bold mb-2">Painting & Finishing</h3>
          <p>Freshen up your home with professional painting services.</p>
        </div>
        <div id="card3" class="bg-gray-100 p-6 rounded shadow hover:shadow-lg transition duration-300" data-aos="zoom-in" data-aos-delay="200">
          <h3 class="text-xl font-bold mb-2">Plumbing & Electrical</h3>
          <p>Certified experts for your home's essential systems.</p>
        </div>
      </div>
    </div>
  </section>

  <!-- Portfolio Section -->
  <section class="py-20 px-6 bg-gray-50" id="portfolio">
    <div class="max-w-6xl mx-auto" data-aos="fade-right">
      <h2 class="text-3xl font-bold text-center mb-12">Our Work</h2>
      <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
        <div class="card">
          <img id="one" src="images/pexels-fotoaibe-1643384.jpg" class="rounded shadow w-full object-cover" alt="Modern Living Room Design" data-aos="fade-in" />
            <p>Kitchen</p> </div>
            <div class="card"> <img id="to" src="images/bedroom.jpg" class="rounded shadow w-full object-cover" alt="Stylish Bedroom Project" data-aos="fade-in" data-aos-delay="100" />
            <p>Bedroom</p></div>
         
            <div class="card"> <img id="to" src="images/living-room.jpg" class="rounded shadow w-full object-cover" alt="Stylish Bedroom Project" data-aos="fade-in" data-aos-delay="100" />
              <p>Living Room</p></div>
            
              
      </div>
    </div>
  </section>

  <!-- Why Choose Us -->
  <section class="py-20 px-6" id="why">
    <div class="max-w-4xl mx-auto text-center" data-aos="flip-up">
      <h2 class="text-3xl font-bold mb-6">Why Choose Us?</h2>
      <ul class="space-y-4 text-lg">
        <li>✅ 10+ Years Experience</li>
        <li>✅ Free Estimates</li>
        <li>✅ Honest Pricing</li>
        <li>✅ On-Time Project Delivery</li>
      </ul>
    </div>
  </section>

  <!-- Testimonials -->
  <section class="bg-gray-100 py-20 px-6" id="testimonials">
    <div class="max-w-4xl mx-auto text-center" data-aos="fade-down">
      <h2 class="text-3xl font-bold mb-10">What Clients Say</h2>
      <blockquote class="italic mb-6">“They turned my old kitchen into a dream space. Highly professional and fast!”</blockquote>
      <p class="font-bold">— Sarah M.</p>
    </div>
  </section>

  <!-- Contact Section -->
  <section class="py-20 px-6" id="contact">
    <div class="max-w-4xl mx-auto" data-aos="fade-up">
      <h2 class="text-3xl font-bold text-center mb-6">Contact Us</h2>
      <form class="space-y-4" method="post">
        <input type="text" placeholder="Your Name" name="name" class="w-full border p-3 rounded" required />
        <input type="email" placeholder="Your Email" name="email" class="w-full border p-3 rounded" required />
        <input type="tel" name="mobile" pattern="\d{10}" inputmode="numeric" name="mobile"
        placeholder="Enter Mobile Number" class="w-full form-control border p-3 rounded">
        <button type="submit" name="submit" class="bg-yellow-500 hover:bg-yellow-600 text-white px-6 py-2 rounded">Send Message</button>
      </form>
    </div>
  </section>

  <footer class="text-center py-6 bg-gray-800 text-white">
    &copy; 2025 Local House Contractor. All rights reserved.
  </footer>

  <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
  <script>
    AOS.init({ duration: 1000 });
  </script>

<script>
  document.querySelectorAll('.navbar-nav .nav-link').forEach(link => {
    link.addEventListener('click', () => {
      const navbarToggler = document.querySelector('.navbar-toggler');
      if (window.getComputedStyle(navbarToggler).display !== 'none') {
        navbarToggler.click(); // auto close nav on link click (mobile)
      }
    });
  });
</script>
<footer class="bg-gray-800 text-white">
  <div class="max-w-6xl mx-auto px-6 py-10 grid grid-cols-1 md:grid-cols-3 gap-8">
    
    <!-- Logo & Tagline -->
    <div>
      <img src="images/BASir ansari.png" alt="Logo" class="h-14 mb-3">
      <p class="text-sm text-gray-400">Building dreams with precision and passion.</p>
    </div>

    <!-- Quick Links -->
    <div>
      <h3 class="font-bold text-lg mb-4">Quick Links</h3>
      <ul class="space-y-2 text-gray-300">
        <li><a href="#about" class="hover:text-yellow-400 transition">About</a></li>
        <li><a href="#services" class="hover:text-yellow-400 transition">Services</a></li>
        <li><a href="#portfolio" class="hover:text-yellow-400 transition">Portfolio</a></li>
        <li><a href="#contact" class="hover:text-yellow-400 transition">Contact</a></li>
      </ul>
    </div>

    <!-- Contact Info -->
    <div>
      <h3 class="font-bold text-lg mb-4">Contact Info</h3>
      <p class="text-gray-300 text-sm mb-2">📍 </p>
      <p class="text-gray-300 text-sm mb-2">📞 +92 300 1234567</p>
      <p class="text-gray-300 text-sm">✉️ basir@example.com</p>
      <!-- Socials -->
      <div class="mt-4 flex space-x-4">
        <a href="#" class="text-gray-400 hover:text-yellow-400"><i class="fab fa-facebook-f"></i></a>
        <a href="#" class="text-gray-400 hover:text-yellow-400"><i class="fab fa-instagram"></i></a>
        <a href="#" class="text-gray-400 hover:text-yellow-400"><i class="fab fa-whatsapp"></i></a>
      </div>
    </div>
    
  </div>


  <div class="text-center text-sm text-gray-400 border-t border-gray-700 py-4">
    &copy; 2025 Basir Ansari Contractors. All rights reserved.
  </div>
</footer>






<!-- Popup Form -->
<div id="popupForm" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 hidden">
  <div class="bg-white rounded-xl shadow-xl w-full max-w-md p-6 relative animate__animated animate__fadeInDown">
    <button id="closePopupForm" class="absolute top-3 right-3 text-gray-500 hover:text-red-500 text-xl font-bold">&times;</button>
    <h2 class="text-xl font-bold mb-4 text-center text-gray-800">Contact Us</h2>
    <form method="POST" class="space-y-4" method="post">
      <input type="text" name="name" placeholder="Your Name" required class="w-full border p-3 rounded" />
      <input type="email" name="email" placeholder="Your Email" required class="w-full border p-3 rounded" />
      <input type="tel" name="mobile" placeholder="Your Mobile Number" pattern="\d{10}" required class="w-full border p-3 rounded" />
      <div class="text-center">
        <button type="submit" name="submit" class="bg-yellow-500 hover:bg-yellow-600 text-white px-6 py-2 rounded">Send</button>
      </div>
    </form>
  </div>
</div>
 
<script>
// Show the popup after 20 seconds
  setTimeout(() => {
    document.getElementById("popupForm").classList.remove("hidden");
  }, 2000); // 20000ms = 20 seconds

  // Close button
  document.getElementById("closePopupForm").addEventListener("click", () => {
    document.getElementById("popupForm").classList.add("hidden");
  });


</script>

</body>
</html>

<?php
 $con = mysqli_connect("localhost", "root", "", "info");
if (isset($_POST['submit'])) {
  $a=mysqli_real_escape_string($con,htmlspecialchars($_POST['name']));
  $b = mysqli_real_escape_string($con, htmlspecialchars($_POST['email']));
  $c = mysqli_real_escape_string($con, htmlspecialchars($_POST['mobile']));
  $q = mysqli_query($con, "INSERT INTO data (Name, Email, Mobileno) VALUES ('$a', '$b', '$c')");
  if ($q) {
    echo "<script>alert('I Will Contact you with in 2 & 3 days✔');</script>";
} else {
    echo "<script>alert('Your information was not collected. Please try again.');</script>";
}

}
?>